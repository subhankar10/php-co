<?php
class user_model extends CI_model() {
function create ($formArray){
$this->db->insert('users',$formArray);
}
}
?>