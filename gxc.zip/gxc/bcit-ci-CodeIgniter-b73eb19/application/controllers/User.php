<?php 
class user extends CI_controller{
function create() {
    // $this->load->models('user_model');
    $this->form_validation->set_rules('name','Name','required');
    $this->form_validation->set_rules('email','Email','required');
if($this->form_validation->run() == false){
$this->load->view('create');
} else{
$formArray = Array();
$formArray['name'] = $this->input->post('name');
$formArray['email'] = $this->input->post('email');
$formArray['created_at'] = date('y-m-d');
$this->user_model->create($formArray);
$this->session->set_falsedata('sucess','record added sucessfully');
redirect(base_url().'index.php/User/index');

}


} //1st function end.
function edit(){
    $this->load->view('edit');
}
    
}
?>